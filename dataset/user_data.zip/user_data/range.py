import os
import glob
import json
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# ==== 路径设置 ====
script_dir = os.path.dirname(__file__)
base_dir = os.path.join(script_dir, "range")
eeg_dir = os.path.join(base_dir, "eeg")
hrv_dir = os.path.join(base_dir, "hrv")
output_dir = os.path.join(script_dir, "output", "summary")
os.makedirs(output_dir, exist_ok=True)

# ==== 匹配 CSV 和 JSON 文件 ====
eeg_files = sorted(glob.glob(os.path.join(eeg_dir, "*.[cC][sS][vV]")) +
                   glob.glob(os.path.join(eeg_dir, "*.json")))

hrv_files = sorted(glob.glob(os.path.join(hrv_dir, "*.[cC][sS][vV]")) +
                   glob.glob(os.path.join(hrv_dir, "*.json")))

# ==== 读取文件函数 ====
def load_json_or_csv(path):
    with open(path, "r") as f:
        content = f.read().strip()
        try:
            data = json.loads(content)
        except:
            df = pd.read_csv(path)
            data = df.to_dict(orient="records")[0]
    return data

# ==== 合并数据 ====
records = []

for eeg_file in eeg_files:
    fname = os.path.basename(eeg_file)
    user_part = fname.split("_")[0]  # user1, user17 ...
    user_num = int(user_part.replace("user", ""))

    # 判断状态
    if "_relax_" in fname or "_relax" in fname:
        state = "relax"
    else:
        state = "relax" if user_num <= 16 else "device"

    # 读取 EEG 数据
    try:
        eeg_data = load_json_or_csv(eeg_file)
        attention_low, attention_high = eeg_data.get("attention", [None, None])
        stress_max = eeg_data.get("stress_max", None)
    except Exception as e:
        print(f"Error reading EEG file {eeg_file}: {e}")
        continue

    # 找对应 HRV 文件
    if state == "device":
        hrv_file = os.path.join(hrv_dir, f"{user_part}_range.csv")
        if not os.path.exists(hrv_file):
            hrv_file = os.path.join(hrv_dir, f"{user_part}_range.json")
    else:
        hrv_file = os.path.join(hrv_dir, f"{user_part}_relax_range.csv")
        if not os.path.exists(hrv_file):
            hrv_file = os.path.join(hrv_dir, f"{user_part}_relax_range.json")
        if not os.path.exists(hrv_file):  # fallback
            hrv_file = os.path.join(hrv_dir, f"{user_part}_range.csv")
            if not os.path.exists(hrv_file):
                hrv_file = os.path.join(hrv_dir, f"{user_part}_range.json")

    # 读取 HRV 数据
    try:
        hrv_data = load_json_or_csv(hrv_file)
    except Exception as e:
        print(f"Error reading HRV file {hrv_file}: {e}")
        continue

    # 添加记录
    records.append({
        "user_id": user_part,
        "state": state,
        "hrv_low": hrv_data.get("hrv_low", None),
        "hrv_high": hrv_data.get("hrv_high", None),
        "attention_low": attention_low,
        "attention_high": attention_high,
        "stress_max": stress_max
    })

# ==== 保存合并表 ====
all_users_file = os.path.join(output_dir, "all_users_status.csv")
if records:
    df = pd.DataFrame(records)
    df.to_csv(all_users_file, index=False)
    print(f"Combined DataFrame saved to {all_users_file}")
else:
    print("No data was loaded. Please check paths and file formats.")
    exit()


# ==== 整体状态比较 ====
summary = df.groupby('state').agg({
    'hrv_low': ['mean','std'],
    'hrv_high': ['mean','std'],
    'attention_low': ['mean','std'],
    'attention_high': ['mean','std'],
    'stress_max': ['mean','std']
}).reset_index()

summary_file = os.path.join(output_dir, "status_summary.csv")
summary.to_csv(summary_file, index=False)

# ==== 整体状态比较（保留 low/high 指标） ====
summary = df.groupby('state').agg({
    'hrv_low': ['mean','std'],
    'hrv_high': ['mean','std'],
    'attention_low': ['mean','std'],
    'attention_high': ['mean','std'],
    'stress_max': ['mean','std']
}).reset_index()

summary_file = os.path.join(output_dir, "status_summary.csv")
summary.to_csv(summary_file, index=False)
print(f"Overall summary saved to {summary_file}")
print(summary)

# ==== 可视化 ====
sns.set(style="whitegrid")

# HRV Low & High 箱型图
plt.figure(figsize=(12,5))
plt.subplot(1,2,1)
sns.boxplot(x='state', y='hrv_low', data=df)
plt.title("HRV Low Comparison: Relax vs Device")
plt.subplot(1,2,2)
sns.boxplot(x='state', y='hrv_high', data=df)
plt.title("HRV High Comparison: Relax vs Device")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "hrv_low_high_boxplot.png"))
plt.close()

# Attention Low & High 箱型图
plt.figure(figsize=(12,5))
plt.subplot(1,2,1)
sns.boxplot(x='state', y='attention_low', data=df)
plt.title("Attention Low Comparison: Relax vs Device")
plt.subplot(1,2,2)
sns.boxplot(x='state', y='attention_high', data=df)
plt.title("Attention High Comparison: Relax vs Device")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "attention_low_high_boxplot.png"))
plt.close()

# Stress Max 箱型图
plt.figure(figsize=(6,4))
sns.boxplot(x='state', y='stress_max', data=df)
plt.title("Stress Max Comparison: Relax vs Device")
plt.savefig(os.path.join(output_dir, "stress_max_boxplot.png"))
plt.close()


print("All plots saved to output/summary/")
